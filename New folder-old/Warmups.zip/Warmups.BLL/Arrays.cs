﻿using System;

namespace Warmups.BLL
{
    public class Arrays
    {

        public bool FirstLast6(int[] numbers)
        {
            throw new NotImplementedException();
        }

        public bool SameFirstLast(int[] numbers)
        {
            throw new NotImplementedException();
        }
        public int[] MakePi(int n)
        {
            throw new NotImplementedException();
        }
        
        public bool CommonEnd(int[] a, int[] b)
        {
            throw new NotImplementedException();
        }
        
        public int Sum(int[] numbers)
        {
            throw new NotImplementedException();
        }
        
        public int[] RotateLeft(int[] numbers)
        {
            throw new NotImplementedException();
        }
        
        public int[] Reverse(int[] numbers)
        {
            throw new NotImplementedException();
        }
        
        public int[] HigherWins(int[] numbers)
        {
            throw new NotImplementedException();
        }
        
        public int[] GetMiddle(int[] a, int[] b)
        {
            throw new NotImplementedException();
        }
        
        public bool HasEven(int[] numbers)
        {
            throw new NotImplementedException();
        }
        
        public int[] KeepLast(int[] numbers)
        {
            throw new NotImplementedException();
        }
        
        public bool Double23(int[] numbers)
        {
            throw new NotImplementedException();
        }
        
        public int[] Fix23(int[] numbers)
        {
            throw new NotImplementedException();
        }
        
        public bool Unlucky1(int[] numbers)
        {
            throw new NotImplementedException();
        }
        
        public int[] Make2(int[] a, int[] b)
        {
            throw new NotImplementedException();
        }

    }
}
